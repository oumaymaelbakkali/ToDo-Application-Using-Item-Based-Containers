#include "dialog.h"
#include "ui_dialog.h"
#include"taskapp.h"
#include<QDateTime>

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
//    QRegExp exp{"[A-Z][a-zA-Z]{0,10}"};
//    ui->lineEdit->setValidator(new QRegExpValidator(exp));

}

Dialog::~Dialog()
{
    delete ui;
}
QString Dialog::Descri() const
  {
      return ui->lineEdit->text();
  }

QString Dialog::Combo() {
    return ui->comboBox->currentText();


}
bool Dialog::checkbox(){
if(ui->checkBox->isChecked())
    return 0;
else
    return 1;
}
QString Dialog::Date() const{
    return ui->dateEdit->text();
}
bool Dialog::CompareDate(){
    QDate Date=QDate::currentDate();
if(ui->dateEdit->text()==Date.toString("dd/MM/yyyy")){
        return 0;

}else
        return 1;
}




#include "taskapp.h"
#include "ui_taskapp.h"
#include <QMessageBox>
#include "dialog.h"
#include<QListWidgetItem>
#include<QDate>

TaskApp::TaskApp(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::TaskApp)
{
    ui->setupUi(this);
}

TaskApp::~TaskApp()
{
    delete ui;
}


void TaskApp::on_actionquit_triggered()
{
    this->close();

}


void TaskApp::on_actionAboutQT_triggered()
{
    QMessageBox::aboutQt(this,"AboutQT");
}






void TaskApp::on_actionNewtask_triggered()
{   ui->listWidget->show();
    ui->listWidget_2->show();
    ui->listWidget_3->show();
    Dialog D;
    QDateTime now = QDateTime::currentDateTime();
    auto replay=D.exec();
    if(replay== QDialog::Accepted && D.checkbox()==1 && D.CompareDate()==0){
        QListWidgetItem *item=new QListWidgetItem;
        item->setText(QString( D.Descri()+"  "+D.Combo() +"  " +"Due :"+"  " + D.Date()));
        item->setIcon(QIcon(":/new.png"));
        ui->listWidget->addItem(item);

    }else if(replay==QDialog::Accepted && D.checkbox()==1 && D.CompareDate()==1){
        QListWidgetItem *item2=new QListWidgetItem;
        item2->setText(QString( D.Descri()+"  "+D.Combo() +"  " +"Due :"+"  " + D.Date()+"   tag : 1"));
        item2->setIcon(QIcon(":/task-planning.png"));
        ui->listWidget_2->addItem(item2);

    }else if(replay== QDialog::Accepted && D.checkbox()==0 && D.CompareDate()==1){

        QListWidgetItem *item1=new QListWidgetItem;
        item1->setText(QString( D.Descri()+"  "+D.Combo() +"  " +"Due :"+"  " + D.Date()+"   tag : 0"));
        item1->setIcon(QIcon(":/task-completed.png"));
        ui->listWidget_3->addItem(item1);

   }



}





void TaskApp::on_actiontaskcompleted_triggered()

{  ui->listWidget_3->show();
   ui->listWidget->hide() ;
   ui->listWidget_2->hide();

}

void TaskApp::on_actiontaskplanning_triggered()
{  ui->listWidget_2->show();
    ui->listWidget->hide() ;
    ui->listWidget_3->hide();

}

void TaskApp::on_actionDelete_triggered()
{
   QListWidgetItem *it= ui->listWidget->takeItem(mnSelected);
   QListWidgetItem *it1= ui->listWidget_2->takeItem(mnSelected1);
   QListWidgetItem *it2= ui->listWidget_3->takeItem(mnSelected2);
   delete it;
   delete it1;
   delete it2;
}

void TaskApp::on_listWidget_currentRowChanged(int currentRow)
{
    mnSelected = currentRow;
}

void TaskApp::on_listWidget_2_currentRowChanged(int currentRow)
{
  mnSelected1 = currentRow;
}

void TaskApp::on_listWidget_3_currentRowChanged(int currentRow)
{
    mnSelected2 = currentRow;
}

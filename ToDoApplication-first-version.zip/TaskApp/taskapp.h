#ifndef TASKAPP_H
#define TASKAPP_H

#include <QMainWindow>
#include<QSettings>

QT_BEGIN_NAMESPACE
namespace Ui { class TaskApp; }
QT_END_NAMESPACE

class TaskApp : public QMainWindow
{
    Q_OBJECT

public:
    TaskApp(QWidget *parent = nullptr);
    ~TaskApp();

private slots:
    void on_actionquit_triggered();
    void on_actionAboutQT_triggered();
    void on_actionNewtask_triggered();
    void on_actiontaskcompleted_triggered();

    void on_actiontaskplanning_triggered();

    void on_actionDelete_triggered();

    void on_listWidget_currentRowChanged(int currentRow);

    void on_listWidget_2_currentRowChanged(int currentRow);

    void on_listWidget_3_currentRowChanged(int currentRow);

private:
    Ui::TaskApp *ui;
    int mnSelected=-1;
    int mnSelected1=-1;
    int mnSelected2=-1;
};
#endif // TASKAPP_H
